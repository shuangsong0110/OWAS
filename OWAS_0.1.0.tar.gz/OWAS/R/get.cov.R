#' @title Generate LD files
#' @description Using this function to generate blockwise LD matrix
#' @param chr chromosome, can be a integer from 1 to 22, or 'all'
#' @param path specify the path for processed LD files
#' @param LD.path path for plink bfiles for the LD reference;(e.g. 1000 Genome Project)
#' @param plink.path path for plink software
#' @param gwas.stats GWAS summary statistics, should be a data.frame including columns: 'chr', 'SNP', 'ref', 'alt', 'z'
#' @param gene.pos The hg19 position for gene promoters can be downloaded from
#'
#' \url{http://web.stanford.edu/~zduren/CoupledNMF/}
#'
#' We use the Promoter_100k_hg19.bed file directly here.
#'
#' @import  EBPRS data.table stats utils
#' @export
#'
#'
get.cov <- function(chr, path, gene.pos, LD.path, plink.path, gwas.stats){
  dir.create(path,recursive = T)
  setwd(path)
  if(chr == 'all'){chr0 <- 1:22}
  chr0 <- chr
  for(chr in chr0){
  region <- 5000
  path0 <- paste0(path,"/dat/chr",chr)
  dir.create(path0,recursive = T)
  setwd(path0)

  gene.new <- gene.pos
  gene.new1 <- gene.new[which(gene.new$V1==paste0("chr",chr))]
  write.table(gene.new1,paste0("gene2_chr",chr,".txt"),quote=F,row.names=F,col.names=T)
  gene2 <- fread(paste0("gene2_chr",chr,".txt"))
  tss0 <- tss1 <- list()
  for(i in 1:dim(gene2)[1]){
    if((gene2$V3[i]-gene2$V2[i])%%region==0){
      tss0[[i]] <- seq(gene2$V2[i],gene2$V3[i]-region,region)
      tss1[[i]] <- seq(gene2$V2[i]+region,gene2$V3[i],region)
    }else{
      tss0[[i]] <- seq(gene2$V2[i],gene2$V3[i],region)
      tss1[[i]] <- c(seq(gene2$V2[i]+region,gene2$V3[i],region),gene2$V3[i])
    }
  }
  gname <- gene2$V4
  save(list=c("gname","tss0","tss1"),file=paste0("1_gene_ref_chr",chr,".RData"))
  #dir.create(paste0("./ctype/",ctype),recursive = TRUE)
   dir.create("./cov")
   gene.dup <- tss0.all <- tss1.all <- c()
   ind <- c()
   #sc2 <- fread(paste0("/gpfs/ysm/pi/zhao-data/ss3789/twas/score/mcf7/result_chr",chr,"_mcf7.txt"))
   k <- 1
   for(i in 1:length(gname)){
     num <- length(tss0[[i]])
     for(j in 1:num){
       gene.dup[k] <- gname[i]
       tss0.all[k] <- tss0[[i]][j]
       tss1.all[k] <- tss1[[i]][j]
       ind[k] <- j
        k <- k+1
    #   cat(as.character(gname[i]),i,"  ",j,"\n")
     }
   }
   dat <- data.frame(chr=rep(22,length(gene.dup)),tss0.all,tss1.all,ind=1:length(gene.dup))
   gwas <- gwas.stats[which(gwas.stats$chr==chr),]
   write.table(gwas.stats$SNP,'gwas.snp.txt',quote=F,row.names=F,col.names=F)
   system(paste0(plink.path,' --bfile ',LD.path,' --extract ',path,'/dat/chr',chr,'/gwas.snp.txt --make-bed --out ',path,'/dat/chr',chr,'/LD'))
   for(j in 1:nrow(dat)){
     write.table(dat[j,],paste0('./cov/region_',j,'.txt'),quote=F,row.names = F,col.names = F,sep='\t')
     system(paste0(plink.path,' --bfile ',path,'/dat/chr',chr,'/LD --extract ',path,'/dat/chr',chr,'/cov/region_',j,'.txt  --allow-no-sex --make-bed --out ',
                   path,'/dat/chr',chr,'/cov/region_',j,' --range'))
   }
   for(j in 1:nrow(dat)){
     if(!file.exists(paste0(path,'/dat/chr',chr,'/cov/region_',j,'.bed'))){
       system(paste0('rm ',path,'/dat/chr',chr,'/cov/region_',j,'.txt'))
       system(paste0('rm ',path,'/dat/chr',chr,'/cov/region_',j,'.log'))
     }
   }
   dat.all <- data.frame(gene=gene.dup,start=tss0.all,end=tss1.all,region=ind,ind=1:length(gene.dup))
   write.table(dat.all,paste0(path,"/dat/chr",chr,'/dat.all.txt'),quote=F,col.names=T,row.names=F)
  }
}
