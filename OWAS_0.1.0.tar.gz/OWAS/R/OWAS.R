#' @title Main function OWAS
#' @description The main function of our package, through which we can calculate OWAS summary statistics
#'
#' @param path specify the path for processed LD files
#' @param sc the openness score data, should be a data.frame including columns : 'chr', 'SNP', 'ref', 'alt', 'score'
#' @param gwas.stats GWAS summary statistics, should be a data.frame including columns: 'chr', 'SNP', 'ref', 'alt', 'z'
#' @param chr chromosome, can be a integer from 1 to 22, or 'all'
#' @param ctype cell type (used for clarify the file name)
#' @return a list containing OWAS summary statistics for all chromosomes
#' @import  data.table stats utils
#' @importFrom  EBPRS read_plink
#' @export
#'


OWAS <- function(path, chr, gwas.stats, sc, ctype='celltype'){
  stats <- list()
  tt <- 1
  if(chr=='all'){chr0 <- 1:22}else{chr0 <- chr}
  for(chr in chr0){
    pp <- which(gwas.stats$chr==chr)
    gwas1 <- gwas.stats[pp,]
    gwas1$z[which(is.na(gwas1$z))] <- 0
    pp <- which(sc$chr==chr)
    sc1 <- sc[pp,]
    sc1$score[which(is.na(sc1$score))] <- 0
    dat <- merge(gwas1,sc1,by='SNP')
    sign1 <- agtc(dat$ref.x,dat$alt.x,dat$ref.y,dat$alt.y)
    dat$score <- sign1*dat$score
    gene <- fread(paste0(path,'/dat/chr',chr,'/dat.all.txt'))
    sigma_g <- z_g <- rep(0,nrow(gene))
    p_g <- rep(1,nrow(gene))
    for(j in 1:nrow(gene)){
      if(file.exists(paste0(path,'/dat/chr',chr,'/cov/region_',j,'.bed'))){
        LD <- read_plink(paste0(path,'/dat/chr',chr,'/cov/region_',j))
        LD$bim$ind <- 1:nrow(LD$bim)
        bed <- bedNA(LD$bed)

        #bed[is.na(bed)] <- 0
        colnames(LD$bim)[2] <- 'SNP'

        bim <- merge(LD$bim,dat,by='SNP')
      if(nrow(bim)==0){
        next
      }else if(nrow(bim)==1){
        covm <- var(bed[,bim$ind])
        sign2 <- agtc(bim$V5,bim$V6,bim$ref.x,bim$alt.x)
        bim$z <- bim$z*sign2
        bim$score <- bim$score*sign2
        sigma_g[j] <- as.numeric(sqrt(t(bim$score)%*% covm %*% bim$score))
        #print("k2")
        sigma_l <- sqrt(covm)
        if(sigma_g[j]==0){
          z_g[j] <- 0
          p_g[j] <- 1
        }else{
          z_g[j] <- sum(z_l*sigma_l*bim$score)/sigma_g[j]
          p_g[j] <- pnorm(-abs(z_g[j]))*2
        }
      }else{
        covm <- cov(bed[,bim$ind])
        sign2 <- agtc(bim$V5,bim$V6,bim$ref.x,bim$alt.x)
        bim$z <- bim$z*sign2
        bim$score <- bim$score*sign2

        sigma_g[j] <- sqrt(t(bim$score)%*% covm %*% bim$score)
        #print("k2")
        sigma_l <- sqrt(diag(covm))
        z_l <- bim$z
        if(sigma_g[j]==0){
          z_g[j] <- 0
          p_g[j] <- 1
        }else{
          z_g[j] <- sum(z_l*sigma_l*bim$score)/as.numeric(sigma_g[j])
          p_g[j] <- pnorm(-abs(z_g[j]))*2
        }
      }
    }}
    gene$z_g <- z_g
    gene$p_g <- p_g
    path2 <- paste0(path,'/stats/',ctype,'/chr',chr)
    dir.create(path2,recursive = T)
    gene <- data.frame(gene)
    gene1 <- gene[which(gene$p_g<0.05),]
    write.table(gene1,paste0(path2,'OWAS_stats_0.05.txt',quote=F,row.names=F,col.names=T))
    stats[[tt]] <- gene1
    tt <- tt+1
  }
  return(stats)
}








